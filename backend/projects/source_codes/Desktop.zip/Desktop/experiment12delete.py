from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")

db = client["Ravi"]

collection = db["Student"]

collection.delete_one({"name":"John"})
