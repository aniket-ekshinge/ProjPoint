from pymongo import MongoClient

# MongoDB connection
client = MongoClient("mongodb://localhost:27017")

# Select a database
db = client["Ravi"]

# Add data
collection = db["Student"]
data = [{"name": "Sweekar","age":20},{"name": "ImmatureAshutosh","age":19}]



collection.insert_many(data)

# Edit data
collection.update_one({"name": "Sweekar"}, {"$set": {"age": 19}})








